# Mate8

Mate8 soll neuen Studierenden die Möglichkeit geben, neue interessante Leute kennenzulernen. Derzeitig wird das Design in Flutter umgesetzt -> Screenshots von der App folgen bald. Diese App wird für das Modul "Android Programmierung" als eine Portfolio-Prüfung entwickelt.
