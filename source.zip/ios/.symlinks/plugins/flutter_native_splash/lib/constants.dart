part of flutter_native_splash_cli;

// Web-related constants
const String _webFolder = 'web/';
const String _webSplashFolder = '${_webFolder}splash/';
const String _webSplashImagesFolder = '${_webSplashFolder}img/';
const String _webIndex = '${_webFolder}index.html';
const String _webRelativeStyleFile = 'splash/style.css';
const String _webRelativeJSFile = 'splash/splash.js';
