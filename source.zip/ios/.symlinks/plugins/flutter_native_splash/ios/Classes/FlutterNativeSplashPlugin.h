#import <Flutter/Flutter.h>

@interface FlutterNativeSplashPlugin : NSObject<FlutterPlugin>
@end
