@JS()
library remove_splash_from_web;

import "package:js/js.dart";

@JS("removeSplashFromWeb")
external void removeSplashFromWeb();
