package com.miguelruivo.flutter.plugin.countrycodes.country_codes_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
